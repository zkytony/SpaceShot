Decompress the zip file first

Arrow Keys to control directions
Space key to shoot

Have Fun!
You will have to close the game manually by right clicking on the jar archive icon





Copyright Kaiyu Zheng